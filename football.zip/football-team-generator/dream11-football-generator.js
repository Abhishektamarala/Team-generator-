var currentIndex = localStorage.getItem("cricketIndex");
var cteam = matchList[currentIndex];
$("#matchbwn").html(cteam.team1Name + ' vs ' + cteam.team2Name);








var teamer = [JSON.parse(localStorage.getItem("selectedPlayers"))];

var generatedTeam = [];
var fulldata = [];
var creditOfHundredPlayerList = [];

teamer[0].team1gk = []
teamer[0].team2gk = []
teamer[0].matchSelPlayers.goalkeeper.forEach(elm => {
   let  player = `
   <div class="card px-2 py-1 mr-1 bg-info text-white" style="min-width:100px;max-width:300px;">
       `+elm.playerName+`
     </div>`;
     $("#sgk").append(player);
   elm.team.includes(teamer[0].team1Name) ? teamer[0].team1gk.push(elm) : teamer[0].team2gk.push(elm)
});
teamer[0].team1def = []
teamer[0].team2def = []
teamer[0].matchSelPlayers.defender.forEach(elm => {
   let  player = `
   <div class="card px-2 py-1 mr-1 bg-info text-white" style="min-width:100px;max-width:300px;">
       `+elm.playerName+`
     </div>`;
     $("#sdef").append(player);
   elm.team.includes(teamer[0].team1Name) ? teamer[0].team1def.push(elm) : teamer[0].team2def.push(elm)

})
teamer[0].team1mid = []
teamer[0].team2mid = []
teamer[0].matchSelPlayers.middle.forEach(elm => {
   let  player = `
   <div class="card px-2 py-1 mr-1 bg-info text-white" style="min-width:100px;max-width:300px;">
       `+elm.playerName+`
     </div>`;
     $("#smid").append(player);
   elm.team.includes(teamer[0].team1Name) ? teamer[0].team1mid.push(elm) : teamer[0].team2mid.push(elm)

})
teamer[0].team1st = []
teamer[0].team2st = []
teamer[0].matchSelPlayers.straight.forEach(elm => {
   let  player = `
   <div class="card px-2 py-1 mr-1 bg-info text-white" style="min-width:100px;max-width:300px;">
       `+elm.playerName+`
     </div>`;
     $("#sst").append(player);
   elm.team.includes(teamer[0].team1Name) ? teamer[0].team1st.push(elm) : teamer[0].team2st.push(elm)

})
var totplayer =teamer[0].matchSelPlayers.goalkeeper.length + teamer[0].matchSelPlayers.defender.length +teamer[0].matchSelPlayers.middle.length + teamer[0].matchSelPlayers.straight.length;
$('#slen').html(totplayer)
teamer[0].team1srtgk = _.sortBy(teamer[0].team1gk, 'pt').reverse()
teamer[0].team1srtdef = _.sortBy(teamer[0].team1def, 'pt').reverse()
teamer[0].team1srtmid = _.sortBy(teamer[0].team1mid, 'pt').reverse()
teamer[0].team1srtst = _.sortBy(teamer[0].team1st, 'pt').reverse()

teamer[0].team2srtgk = _.sortBy(teamer[0].team2gk, 'pt').reverse()
teamer[0].team2srtdef = _.sortBy(teamer[0].team2def, 'pt').reverse()
teamer[0].team2srtmid = _.sortBy(teamer[0].team2mid, 'pt').reverse()
teamer[0].team2srtst = _.sortBy(teamer[0].team2st, 'pt').reverse()


//   limitation
limitation = { gklimit: { min: 1, max: 4 }, deflimit: { min: 3, max: 6 }, midlimit: { min: 1, max: 4 }, stlimit: { min: 3, max: 6 } };

// findedCombo[16]

gklimit = limitation.gklimit;
deflimit = limitation.deflimit;
midlimit = limitation.midlimit;
stlimit = limitation.stlimit;

var findedCombo = [];

function findcombo(input) {
   for (i = 0; i < input; i++) {
      for (j = 0; j < input; j++) {
         for (k = 0; k < input; k++) {
            for (l = 0; l < input; l++) {
               (i + j + k + l == input) ? findedCombo.push({ i: i, j: j, k: k, l: l }) : null
            }
         }
      }
   }
}

findcombo(11);




var comboOfEleven = [];
function pushcomboofeleven(obj, ix) {
   comboOfEleven.push(obj);
   $("#selCombo").append(`<option value="` + ix + `" onclick="selIndex(` + ix + `)">gk(` + obj.i + `) | def(` + obj.j + `) | mid(` + obj.k + `) | st(` + obj.l + `)</option>`)
}
var ix = -1;
findedCombo.forEach(c => {
   if (

      (gklimit.min <= c.i && gklimit.max >= c.i) &&
      (deflimit.min <= c.j && deflimit.max >= c.j) &&
      (midlimit.min <= c.k && midlimit.max >= c.k) &&
      (stlimit.min <= c.l && stlimit.max >= c.l)

   ) {

      if (c.i + c.j + c.k + c.l == 11) {
         ix = ix + 1;
         pushcomboofeleven({ i: c.i, j: c.j, k: c.k, l: c.l }, ix)
      } else {

      }
   }
})




gkcombo = [];
defcombo = [];
midcombo = [];
stcombo = [];

function combofromtwoTeam(input, array) {
   for (k = 0; k <= input; k++) {
      for (l = 0; l <= input; l++) {

         (k + l == input) ? array.push({ k: k, l: l }) : null
      }
   }

}





function GenerateTeamwithcvc() {
   $("#generatedTeam").html('');
   $("#totalGenCount").html('0 Team generated.');
   currentIndex = $("#selCombo").val();
   console.log(currentIndex);
   var c = comboOfEleven[currentIndex];
   console.log(c);
   GenerateTeam(c.i, c.j, c.k, c.l);

}


function findteam(arr, role) {
   return arr['Team1'].slice(0, 1).concat(arr['Team2'].slice(0, 2));

}
function player(pl) {
   let c = 0;
   var a = ''
   pl.forEach(p => {

      c = c + parseFloat(p.credit);
   })


   setTimeout(() => {
      if (c <= 100) {

         creditOfHundredPlayerList.push({ credit: c, players: pl })
      }
   })




}


function GenerateTeam(i, j, k, l) {
   // gener
   fulldata = [];
   combofromtwoTeam(i, gkcombo = []);
   combofromtwoTeam(j, defcombo = []);
   combofromtwoTeam(k, midcombo = []);
   combofromtwoTeam(l, stcombo = []);






   gkcombo.forEach(gk => {
      defcombo.forEach(bt => {
         midcombo.forEach(mid => {
            stcombo.forEach(st => {
               teamer[0].team1srtgk

               var glk = teamer[0].team1srtgk.slice(0, gk.k).concat(teamer[0].team2srtgk.slice(0, gk.l));
               var def = teamer[0].team1srtdef.slice(0, bt.k).concat(teamer[0].team2srtdef.slice(0, bt.l));
               var midd = teamer[0].team1srtmid.slice(0, mid.k).concat(teamer[0].team2srtmid.slice(0, mid.l));
               var str = teamer[0].team1srtst.slice(0, st.k).concat(teamer[0].team2srtst.slice(0, st.l));

               let teams = [...glk, ...def, ...midd, ...str];
               (teams.length == 11) ? fulldata.push({ team: teams }) : null;



            })
         })
      })
   })


   setTimeout(() => {
      generateTeamWithCapVC = [];
      creditOfHundredPlayerList = [];
      if(fulldata.length == 0){
         if(teamer[0].matchSelPlayers.goalkeeper.length <  i ){
          return  alert(`Please select more goal keeper to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
         }
         if(teamer[0].matchSelPlayers.defender.length <   j) {
            return  alert(`Please select more defender  to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
         }
         if(teamer[0].matchSelPlayers.middle.length <  k) {
            return  alert(`Please select more mid rounder to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
         }
         if(teamer[0].matchSelPlayers.straight.length <  l) {
            return  alert(`Please select more straight to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
         }
      }
      fulldata.forEach((pl, ix) => {
         player(pl.team);

         if ((ix + 1) == fulldata.length) {
            debugger;
            setTimeout(() => {
               if(creditOfHundredPlayerList.length == 0){
                  if(teamer[0].matchSelPlayers.goalkeeper.length <   i ){
                   return  alert(`Please select more wicket keeper to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
                  }
                  if(teamer[0].matchSelPlayers.defender.length <  j) {
                     return  alert(`Please select more defender  to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
                  }
                  if(teamer[0].matchSelPlayers.middle.length <   k) {
                     return  alert(`Please select more mid rounder to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
                  }
                  if(teamer[0].matchSelPlayers.straight.length <  l) {
                     return  alert(`Please select more straight to generate this combination. gk(` + i + `) | def(` + j + `) | mid(` + k + `) | st(` + l + `)`);
                  }
               }else{
                  $("#totalGenCount").text(creditOfHundredPlayerList.length + ' Teams Generated.');

                  creditOfHundredPlayerList.forEach((p,inx )=> {
                     var sortItem = _.sortBy(p.players, 'pt').reverse();
   
                     const capvc = {
                        players: p.players,
                        cap: sortItem[0],
                        vc: sortItem[1],
                        credit: p.credit
                     }
                     generateTeamWithCapVC.push(capvc);
                     console.log(capvc)
                     loadGenerateTeam(capvc);
   
                    
                     //   p['capvc'] = capvc;
                  })
               }
              




            })
         }


      })
   })



   // gener
}

function loadGenerateTeam(gteams) {

   let c = gteams.cap;
   let vc = gteams.vc;
   let credit = gteams.credit;
   let img = ''

   var gk = "", def = "", mid = "", st = "";
   var defeam = "", gkteam = "", midteam = "", stteam = "";



   gteams.players.forEach((p, ix) => {

      img = '';


      //   if (c.id == p.id) {
      //       role = `<div class="c">c</div>`;

      //    } else if (vc.id == p.id) {
      //       role = `<div class="c">vc</div>`;
      //    } else {
      //       role = `<div></div>`;
      //    }
      let cvc = "";
      if (c.id == p.id) {
         cvc = '<div class="cvc cap">c</div>'
      }
      else if (vc.id == p.id) {
         cvc = '<div class="cvc">vc</div>'
      } else {
         cvc = "";
      }
      if (p.team.includes("-GK")) {
         img = "../img/gk.svg";
         gk = gk + ` 

         <div class="sp">`+ cvc + `
         <div class="text-center img"><img width="20" src="`+ img + `" /></div>
         <div class="text-center name">`+ p.playerName + `</div>
         
         <div class="text-center pt">`+ p.pt + `</div>
         <div class="text-center role">GK</div>
        </div>
        
         `;
      } else if (p.team.includes("-DEF")) {
         img = "../img/def.svg";
         def = def + ` 
         <div class="sp">`+ cvc + `
         <div class="text-center img"><img width="20" src="`+ img + `" /></div>
         <div class="text-center name">`+ p.playerName + `</div>
         
         <div class="text-center pt">`+ p.pt + `</div>
         <div class="text-center role">DEF</div>
        </div>
        
         `;
      } else if (p.team.includes('-MID')) {
         img = "../img/mid.svg";
         mid = mid + ` 
         <div class="sp">`+ cvc + `
         <div class="text-center img"><img width="20" src="`+ img + `" /></div>
         <div class="text-center name">`+ p.playerName + `</div>
         
         <div class="text-center pt">`+ p.pt + `</div>
         <div class="text-center role">MID</div>
        </div>
         
         `;
      } else if (p.team.includes('-ST')) {
         img = "../img/st.svg";
         st = st + ` 
         <div class="sp">`+ cvc + `
         <div class="text-center img"><img width="20" src=`+ img + ` ></div>
         <div class="text-center name">`+ p.playerName + `</div>
         
         <div class="text-center pt">`+ p.pt + `</div>
         <div class="text-center role">ST</div>
        </div>
        
         `;
      }











   });



   setTimeout(() => {
      gkteam = `<div class="gp ggk">
      <div class="text-center row d-flex justify-content-center mb-4">
         `+ gk + `
      </div>
      </div>
     
         
        `

      defeam = `<div class="gp ggk">
           <div class="text-center row d-flex justify-content-center mb-4">
              `+ def + `
           </div>
           </div>
          `  ;
      midteam = `<div class="gp ggk">
           <div class="text-center row d-flex justify-content-center mb-4">
              `+ mid + `
           </div>
           </div>
          `  ;
      stteam = `<div class="gp ggk">
           <div class="text-center row d-flex justify-content-center mb-1">
              `+ st + `
           </div>
           </div>
          `  ;

      $("#generatedTeam").append(
         `<div class="gteam-div"><p class="pl-2 mb-0">Total credit =` + credit + `</p><div class="genteam">` + gkteam + defeam + midteam + stteam + `</div></div>`);
   })

}

