var currentIndex = localStorage.getItem("cricketIndex");
var selectedPlayers =[] ;
var matchWithSelPlayer ={
    goalkeeper: [],
    defender: [],
    middle: [],
    straight:[]
    };
var cteam = matchList[currentIndex];
$(() => {
    
    $("#matchbwn").html(cteam.team1Name +' vs '+cteam.team2Name);

    loadPlayer(cteam);
});

function loadPlayer(match) {
    match.goalkeeper.forEach(p =>{
        $("#gktbody").append(`
        <tr id="p`+p.id+`" onclick="selectPlayer('goalkeeper','`+p.id+`')">
        <td><div class="player">
            <img src="../img/gk.svg" width="20"/> <span>`+p.playerName+`</span>
        </div></td>
        <td>`+p.credit+`</td>
        <td>`+p.pt+`</td>
        </tr>`); 
         
    });
    match.defender.forEach(p =>{
        $("#deftbody").append(`
        <tr id="p`+p.id+`" onclick="selectPlayer('defender','`+p.id+`')">
        <td><div class="player">
            <img src="../img/gk.svg" width="20"/> <span>`+p.playerName+`</span>
        </div></td>
        <td>`+p.credit+`</td>
        <td>`+p.pt+`</td>
        </tr>`);    
    });
    match.middle.forEach(p =>{
        $("#midtbody").append(`
        <tr id="p`+p.id+`" onclick="selectPlayer('middle','`+p.id+`')">
        <td><div class="player">
            <img src="../img/gk.svg" width="20"/> <span>`+p.playerName+`</span>
        </div></td>
        <td>`+p.credit+`</td>
        <td>`+p.pt+`</td>
        </tr>`);     
    });
    match.straight.forEach(p =>{
        $("#sttbody").append(`
        <tr id="p`+p.id+`" onclick="selectPlayer('straight','`+p.id+`')">
        <td><div class="player">
            <img src="../img/gk.svg" width="20"/> <span>`+p.playerName+`</span>
        </div></td>
        <td>`+p.credit+`</td>
        <td>`+p.pt+`</td>
        </tr>`);   
    })
    

    

}

function selectPlayer(role, pid){
    console.log(role, pid)
    const b  = matchList[currentIndex][role].findIndex(x =>x.id== pid);
    if(b !== -1){
        player  = matchList[currentIndex][role][b]
    }
    console.log(player)
  if(player && player.isActive){
      player['isActive'] = false;
      $('#p'+pid).removeClass("table-primary");
    const six = selectedPlayers.findIndex(x=> x.id == pid);
    if(six !== -1){
        selectedPlayers.splice(six, 1);
        
    }else{
        selectedPlayers.push(player)
    }
  }else{
    player['isActive'] = true;
    $('#p'+pid).addClass("table-primary");
    const six = selectedPlayers.findIndex(x=> x.id == pid);
    if(six !== -1){
        selectedPlayers.splice(six, 1);
    }else{
        selectedPlayers.push(player)
    }
  }

  setTimeout(()=>{
    $("#sgk").html('');
    $("#sdef").html('');
    $("#smid").html('');
    $("#sst").html('');
    matchWithSelPlayer.goalkeeper= [];
    matchWithSelPlayer.defender =[];
    matchWithSelPlayer.middle = [];
    matchWithSelPlayer.straight =[];
      selectedPlayers.forEach(pl =>{
            let player = `
                <div class="card px-2 py-1 mr-1 bg-info text-white" style="min-width:100px;max-width:300px;">
                    `+pl.playerName+`
                  </div>
                 `;
                 if(pl.team.includes('-GK') ){
                    matchWithSelPlayer.goalkeeper.push(pl)
                    $("#sgk").append(player);
                }else if(pl.team.includes('-DEF')){
                    matchWithSelPlayer.defender.push(pl)
                    $("#sdef").append(player);
                }else if(pl.team.includes('-MID')){
                    matchWithSelPlayer.middle.push(pl)
                    $("#smid").append(player);
                }else if(pl.team.includes('-ST')){
                    matchWithSelPlayer.straight.push(pl)
                    $("#sst").append(player);
                }
      });
  })
  console.log(selectedPlayers)
  $("#slen").html(selectedPlayers.length)
}

function gotoTeamGenerator(){
    
   if(matchWithSelPlayer.goalkeeper.length < 1){
    return  alert('Please select atleast 1  Goal keeper');
   
   }
   if(matchWithSelPlayer.defender.length < 3){
    return alert('Please select atleast 3 to 5 defender');
    
}
if(matchWithSelPlayer.middle.length < 3){
    return alert('Please select atleast 3 to 5 mid');
    
}
if(matchWithSelPlayer.straight.length < 1){
    return alert('Please select atleast 1 to 3 straight');
    
}


    if((matchWithSelPlayer.middle.length +
        matchWithSelPlayer.defender.length +
        matchWithSelPlayer.straight.length +
        matchWithSelPlayer.goalkeeper.length) <= 11){
        alert("Please add atleast 12 or more players to Continue.")
    }else{
        cteam['matchSelPlayers'] = matchWithSelPlayer;
        localStorage.setItem('selectedPlayers', JSON.stringify(cteam));
        console.log("team", cteam);
       setTimeout(()=>{
        window.location.href="../football-team-generator/prediction.html"
    
       },100)
    }
   
   
}
