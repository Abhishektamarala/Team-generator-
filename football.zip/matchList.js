var matchList = [
    {
        "matchtype": "Mexican League",
        "team1Name": "TIJ",
        "team2Name": "QUE",
        "match": "TIJ vs QUE",
        "date": "21-03-2021, 08:36 AM",
        "time": "",
        "place": "",
        "stadium": "",
        "goalkeeper": [
            {
                "id": "wk1",
                "team": "QUE-GK",
                "playerName": "G Ruiz",
                "pt": 91.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.34%"
            },
            {
                "id": "wk2",
                "team": "QUE-GK",
                "playerName": "G Alcala",
                "pt": 86.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.21%"
            },
            {
                "id": "wk3",
                "team": "TIJ-GK",
                "playerName": "J Orozco",
                "pt": 119.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 78.91%"
            },
            {
                "id": "wk4",
                "team": "TIJ-GK",
                "playerName": "C Higuera",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 8.36%"
            },
            {
                "id": "wk5",
                "team": "TIJ-GK",
                "playerName": "B Diaz",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.38%"
            },
            {
                "id": "wk6",
                "team": "TIJ-GK",
                "playerName": "J Jimenez",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.8%"
            }
        ],
        "defender": [
            {
                "id": "bat1",
                "team": "QUE-DEF",
                "playerName": "D Cervantes",
                "pt": 51.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.57%"
            },
            {
                "id": "bat2",
                "team": "QUE-DEF",
                "playerName": "M Rea",
                "pt": 22.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.51%"
            },
            {
                "id": "bat3",
                "team": "QUE-DEF",
                "playerName": "E Vera",
                "pt": 95.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 12.73%"
            },
            {
                "id": "bat4",
                "team": "QUE-DEF",
                "playerName": "J P Meza",
                "pt": 71.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.89%"
            },
            {
                "id": "bat5",
                "team": "QUE-DEF",
                "playerName": "H Magallanes",
                "pt": -8.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.89%"
            },
            {
                "id": "bat6",
                "team": "QUE-DEF",
                "playerName": "O Mendoza",
                "pt": 63.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 6.04%"
            },
            {
                "id": "bat7",
                "team": "TIJ-DEF",
                "playerName": "G Jara",
                "pt": 145.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 19.36%"
            },
            {
                "id": "bat8",
                "team": "TIJ-DEF",
                "playerName": "B Angulo",
                "pt": 82.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 11.13%"
            },
            {
                "id": "bat9",
                "team": "TIJ-DEF",
                "playerName": "V -Guzman",
                "pt": 48.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 13.7%"
            },
            {
                "id": "bat10",
                "team": "TIJ-DEF",
                "playerName": "J Velazquez",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 74.41%"
            },
            {
                "id": "bat11",
                "team": "TIJ-DEF",
                "playerName": "J Gomez",
                "pt": 65.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 80.77%"
            },
            {
                "id": "bat12",
                "team": "TIJ-DEF",
                "playerName": "V Lorona",
                "pt": 76.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 79.81%"
            },
            {
                "id": "bat13",
                "team": "QUE-DEF",
                "playerName": "J Juarez",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 14.92%"
            },
            {
                "id": "bat14",
                "team": "QUE-DEF",
                "playerName": "A Doldan",
                "pt": 100.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 14.02%"
            },
            {
                "id": "bat15",
                "team": "QUE-DEF",
                "playerName": "J Nava",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 57.88%"
            },
            {
                "id": "bat16",
                "team": "QUE-DEF",
                "playerName": "A Garcia",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.64%"
            },
            {
                "id": "bat17",
                "team": "TIJ-DEF",
                "playerName": "E Tercero",
                "pt": 51.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.64%"
            },
            {
                "id": "bat18",
                "team": "TIJ-DEF",
                "playerName": "M Herrera",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.67%"
            },
            {
                "id": "bat19",
                "team": "TIJ-DEF",
                "playerName": "S Manriquez",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.93%"
            }
        ],
        "middle": [
            {
                "id": "all1",
                "team": "QUE-MID",
                "playerName": "J Ibarra",
                "pt": 4.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 11.64%"
            },
            {
                "id": "all2",
                "team": "QUE-MID",
                "playerName": "J Gurrola",
                "pt": 89.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 80.77%"
            },
            {
                "id": "all3",
                "team": "TIJ-MID",
                "playerName": "F Martinez",
                "pt": 24.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 70.93%"
            },
            {
                "id": "all4",
                "team": "TIJ-MID",
                "playerName": "F Castillo",
                "pt": 122.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 83.92%"
            },
            {
                "id": "all5",
                "team": "QUE-MID",
                "playerName": "A Valencia",
                "pt": 191.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 10.03%"
            },
            {
                "id": "all6",
                "team": "QUE-MID",
                "playerName": "J Montero",
                "pt": 22.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.31%"
            },
            {
                "id": "all7",
                "team": "QUE-MID",
                "playerName": "K Ramirez",
                "pt": 196.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 13.25%"
            },
            {
                "id": "all8",
                "team": "QUE-MID",
                "playerName": "F Madrigal",
                "pt": 222.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 67.07%"
            },
            {
                "id": "all9",
                "team": "TIJ-MID",
                "playerName": "E Pavez",
                "pt": 164.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 15.37%"
            },
            {
                "id": "all10",
                "team": "TIJ-MID",
                "playerName": "M Ruiz",
                "pt": 11.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.95%"
            },
            {
                "id": "all11",
                "team": "QUE-MID",
                "playerName": "K Escamilla",
                "pt": 148.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.47%"
            },
            {
                "id": "all12",
                "team": "QUE-MID",
                "playerName": "G Montes",
                "pt": 97.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.77%"
            },
            {
                "id": "all13",
                "team": "QUE-MID",
                "playerName": "J Canales",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.19%"
            },
            {
                "id": "all14",
                "team": "TIJ-MID",
                "playerName": "L Gamiz",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.06%"
            },
            {
                "id": "all15",
                "team": "TIJ-MID",
                "playerName": "K Balanta",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.99%"
            },
            {
                "id": "all16",
                "team": "TIJ-MID",
                "playerName": "J Cortizo",
                "pt": 20.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.99%"
            },
            {
                "id": "all17",
                "team": "TIJ-MID",
                "playerName": "D Barbona",
                "pt": 147.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.86%"
            },
            {
                "id": "all18",
                "team": "TIJ-MID",
                "playerName": "J Sornoza",
                "pt": 47.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.12%"
            },
            {
                "id": "all19",
                "team": "TIJ-MID",
                "playerName": "J Romero",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.15%"
            },
            {
                "id": "all20",
                "team": "TIJ-MID",
                "playerName": "C Rivera",
                "pt": 67.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.54%"
            }
        ],
        "straight": [
            {
                "id": "bowl1",
                "team": "QUE-ST",
                "playerName": "A Sepulveda",
                "pt": 263.0,
                "credit": 10.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 91.51%"
            },
            {
                "id": "bowl2",
                "team": "QUE-ST",
                "playerName": "F D Costa",
                "pt": 40.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 9.26%"
            },
            {
                "id": "bowl3",
                "team": "TIJ-ST",
                "playerName": "M Manotas",
                "pt": 61.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.59%"
            },
            {
                "id": "bowl4",
                "team": "TIJ-ST",
                "playerName": "M Sansores",
                "pt": 28.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 66.56%"
            },
            {
                "id": "bowl5",
                "team": "QUE-ST",
                "playerName": "H Silveira",
                "pt": 99.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 17.88%"
            },
            {
                "id": "bowl6",
                "team": "QUE-ST",
                "playerName": "J D Santos",
                "pt": 0.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.54%"
            },
            {
                "id": "bowl7",
                "team": "TIJ-ST",
                "playerName": "E Lopez",
                "pt": 74.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.57%"
            },
            {
                "id": "bowl8",
                "team": "QUE-ST",
                "playerName": "J Gallardo",
                "pt": 15.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.42%"
            },
            {
                "id": "bowl9",
                "team": "TIJ-ST",
                "playerName": "G Ogara",
                "pt": 5.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.54%"
            },
            {
                "id": "bowl10",
                "team": "QUE-ST",
                "playerName": "A R Lopez",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.44%"
            },
            {
                "id": "bowl11",
                "team": "QUE-ST",
                "playerName": "J Espino",
                "pt": 4.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.8%"
            }
        ]
    },
    {
        "matchtype": "A League",
        "team1Name": "WEL",
        "team2Name": "BRB",
        "match": "WEL vs BRB",
        "date": "21-03-2021, 10:35 AM",
        "time": "",
        "place": "",
        "stadium": "",
        "goalkeeper": [
            {
                "id": "wk1",
                "team": "WEL-GK",
                "playerName": "S Marinovic",
                "pt": 149.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.78%"
            },
            {
                "id": "wk2",
                "team": "WEL-GK",
                "playerName": "O Sail",
                "pt": 212.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.74%"
            },
            {
                "id": "wk3",
                "team": "BRB-GK",
                "playerName": "J Young",
                "pt": 269.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 83.45%"
            },
            {
                "id": "wk4",
                "team": "BRB-GK",
                "playerName": "M Freke",
                "pt": 62.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.13%"
            }
        ],
        "defender": [
            {
                "id": "bat1",
                "team": "WEL-DEF",
                "playerName": "T Payne",
                "pt": 217.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.66%"
            },
            {
                "id": "bat2",
                "team": "WEL-DEF",
                "playerName": "J McGarry",
                "pt": 291.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 26.06%"
            },
            {
                "id": "bat3",
                "team": "WEL-DEF",
                "playerName": "L McGing",
                "pt": 131.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.54%"
            },
            {
                "id": "bat4",
                "team": "WEL-DEF",
                "playerName": "L DeVere",
                "pt": 156.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.24%"
            },
            {
                "id": "bat5",
                "team": "WEL-DEF",
                "playerName": "J Laws",
                "pt": 169.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 6.2%"
            },
            {
                "id": "bat6",
                "team": "BRB-DEF",
                "playerName": "T Aldred",
                "pt": 297.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 73.94%"
            },
            {
                "id": "bat7",
                "team": "BRB-DEF",
                "playerName": "M Gillesphey",
                "pt": 388.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 89.32%"
            },
            {
                "id": "bat8",
                "team": "BRB-DEF",
                "playerName": "J Hingert",
                "pt": 325.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 89.84%"
            },
            {
                "id": "bat9",
                "team": "BRB-DEF",
                "playerName": "K Trewin",
                "pt": 232.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 61.96%"
            },
            {
                "id": "bat10",
                "team": "WEL-DEF",
                "playerName": "S Taylor",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.6%"
            },
            {
                "id": "bat11",
                "team": "WEL-DEF",
                "playerName": "T A Hudson-Wihongi",
                "pt": 15.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.59%"
            },
            {
                "id": "bat12",
                "team": "WEL-DEF",
                "playerName": "L Fenton",
                "pt": 235.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 6.53%"
            },
            {
                "id": "bat13",
                "team": "BRB-DEF",
                "playerName": "I Powell",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.87%"
            },
            {
                "id": "bat14",
                "team": "BRB-DEF",
                "playerName": "J Courtney-Perkins",
                "pt": 3.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.08%"
            },
            {
                "id": "bat15",
                "team": "BRB-DEF",
                "playerName": "J Brindell-South",
                "pt": 68.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.1%"
            }
        ],
        "middle": [
            {
                "id": "all1",
                "team": "WEL-MID",
                "playerName": "U Davila",
                "pt": 491.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 73.43%"
            },
            {
                "id": "all2",
                "team": "WEL-MID",
                "playerName": "R Piscopo",
                "pt": 279.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 14.45%"
            },
            {
                "id": "all3",
                "team": "WEL-MID",
                "playerName": "C Lewis",
                "pt": 297.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.63%"
            },
            {
                "id": "all4",
                "team": "WEL-MID",
                "playerName": "A Rufer",
                "pt": 422.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 23.03%"
            },
            {
                "id": "all5",
                "team": "BRB-MID",
                "playerName": "C Brown",
                "pt": 433.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 63.12%"
            },
            {
                "id": "all6",
                "team": "BRB-MID",
                "playerName": "J OShea",
                "pt": 468.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 70.86%"
            },
            {
                "id": "all7",
                "team": "BRB-MID",
                "playerName": "R Danzaki",
                "pt": 408.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 12.73%"
            },
            {
                "id": "all8",
                "team": "WEL-MID",
                "playerName": "C Devlin",
                "pt": 368.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.31%"
            },
            {
                "id": "all9",
                "team": "WEL-MID",
                "playerName": "J Sotirio",
                "pt": 151.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.17%"
            },
            {
                "id": "all10",
                "team": "BRB-MID",
                "playerName": "J Ingham",
                "pt": 21.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.03%"
            },
            {
                "id": "all11",
                "team": "BRB-MID",
                "playerName": "R Akbari",
                "pt": 290.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.17%"
            },
            {
                "id": "all12",
                "team": "BRB-MID",
                "playerName": "J Daley",
                "pt": 150.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.07%"
            },
            {
                "id": "all13",
                "team": "BRB-MID",
                "playerName": "J Champness",
                "pt": 93.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.49%"
            },
            {
                "id": "all14",
                "team": "BRB-MID",
                "playerName": "C Demhie",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 0%"
            },
            {
                "id": "all15",
                "team": "WEL-MID",
                "playerName": "M Ridenton",
                "pt": 91.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 21.77%"
            },
            {
                "id": "all16",
                "team": "WEL-MID",
                "playerName": "S Sutton",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 52.26%"
            },
            {
                "id": "all17",
                "team": "BRB-MID",
                "playerName": "D Kim",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 23.54%"
            },
            {
                "id": "all18",
                "team": "BRB-MID",
                "playerName": "K Jelacic",
                "pt": 13.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 11.75%"
            },
            {
                "id": "all19",
                "team": "BRB-MID",
                "playerName": "A Parsons",
                "pt": 14.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.3%"
            }
        ],
        "straight": [
            {
                "id": "bowl1",
                "team": "BRB-ST",
                "playerName": "D Wenzel-Halls",
                "pt": 512.0,
                "credit": 10.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 55.85%"
            },
            {
                "id": "bowl2",
                "team": "BRB-ST",
                "playerName": "S McDonald",
                "pt": 317.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.92%"
            },
            {
                "id": "bowl3",
                "team": "WEL-ST",
                "playerName": "T Hemed",
                "pt": 157.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.7%"
            },
            {
                "id": "bowl4",
                "team": "WEL-ST",
                "playerName": "D Ball",
                "pt": 293.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 80.37%"
            },
            {
                "id": "bowl5",
                "team": "WEL-ST",
                "playerName": "M Muratovic",
                "pt": 130.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 56.74%"
            },
            {
                "id": "bowl6",
                "team": "BRB-ST",
                "playerName": "M Kudo",
                "pt": 10.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.52%"
            },
            {
                "id": "bowl7",
                "team": "BRB-ST",
                "playerName": "G G Mebrahtu",
                "pt": 50.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.08%"
            },
            {
                "id": "bowl8",
                "team": "WEL-ST",
                "playerName": "B Waine",
                "pt": 146.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 14.27%"
            },
            {
                "id": "bowl9",
                "team": "WEL-ST",
                "playerName": "C Lokolingoy",
                "pt": 10.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2%"
            },
            {
                "id": "bowl10",
                "team": "WEL-ST",
                "playerName": "O v Hattum",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.83%"
            }
        ]
    },
    {
        "matchtype": "A League",
        "team1Name": "NJ",
        "team2Name": "ADL",
        "match": "NJ vs ADL",
        "date": "21-03-2021, 12:33 PM",
        "time": "",
        "place": "",
        "stadium": "",
        "goalkeeper": [
            {
                "id": "wk1",
                "team": "ADL-GK",
                "playerName": "J Delianov",
                "pt": 377.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 9.29%"
            },
            {
                "id": "wk2",
                "team": "ADL-GK",
                "playerName": "D Ochsenham",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.32%"
            },
            {
                "id": "wk3",
                "team": "NJ-GK",
                "playerName": "L Italiano",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.54%"
            },
            {
                "id": "wk4",
                "team": "NJ-GK",
                "playerName": "J Duncan",
                "pt": 287.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 83.41%"
            },
            {
                "id": "wk5",
                "team": "ADL-GK",
                "playerName": "J Gauci",
                "pt": 30.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.44%"
            }
        ],
        "defender": [
            {
                "id": "bat1",
                "team": "NJ-DEF",
                "playerName": "C OToole",
                "pt": 346.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 89.82%"
            },
            {
                "id": "bat2",
                "team": "ADL-DEF",
                "playerName": "G Timotheou",
                "pt": 75.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.21%"
            },
            {
                "id": "bat3",
                "team": "ADL-DEF",
                "playerName": "C Nunn",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.77%"
            },
            {
                "id": "bat4",
                "team": "ADL-DEF",
                "playerName": "Y Abetew",
                "pt": 75.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.55%"
            },
            {
                "id": "bat5",
                "team": "ADL-DEF",
                "playerName": "J Elsey",
                "pt": 286.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.32%"
            },
            {
                "id": "bat6",
                "team": "ADL-DEF",
                "playerName": "M Jakobsen",
                "pt": 288.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.99%"
            },
            {
                "id": "bat7",
                "team": "ADL-DEF",
                "playerName": "M Marrone",
                "pt": 26.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.55%"
            },
            {
                "id": "bat8",
                "team": "ADL-DEF",
                "playerName": "N Smith",
                "pt": 346.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 8.52%"
            },
            {
                "id": "bat9",
                "team": "ADL-DEF",
                "playerName": "R Strain",
                "pt": 187.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.1%"
            },
            {
                "id": "bat10",
                "team": "ADL-DEF",
                "playerName": "J Lopez-Rodriguez",
                "pt": 139.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.98%"
            },
            {
                "id": "bat11",
                "team": "NJ-DEF",
                "playerName": "N Topor-Stanley",
                "pt": 397.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 10.73%"
            },
            {
                "id": "bat12",
                "team": "NJ-DEF",
                "playerName": "N Boogaard",
                "pt": 337.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 13.05%"
            },
            {
                "id": "bat13",
                "team": "NJ-DEF",
                "playerName": "L Jackson",
                "pt": 29.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 41.26%"
            },
            {
                "id": "bat14",
                "team": "NJ-DEF",
                "playerName": "J Koutroumbis",
                "pt": 337.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 92.15%"
            },
            {
                "id": "bat15",
                "team": "NJ-DEF",
                "playerName": "M Millar",
                "pt": 50.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 82.96%"
            },
            {
                "id": "bat16",
                "team": "NJ-DEF",
                "playerName": "P Langlois",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.99%"
            },
            {
                "id": "bat17",
                "team": "NJ-DEF",
                "playerName": "B Archbold",
                "pt": 14.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.77%"
            },
            {
                "id": "bat18",
                "team": "ADL-DEF",
                "playerName": "T Lynch",
                "pt": 0.0,
                "credit": 7.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.54%"
            }
        ],
        "middle": [
            {
                "id": "all1",
                "team": "ADL-MID",
                "playerName": "S Mauk",
                "pt": 442.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 33.74%"
            },
            {
                "id": "all2",
                "team": "ADL-MID",
                "playerName": "B Halloran",
                "pt": 373.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.96%"
            },
            {
                "id": "all3",
                "team": "ADL-MID",
                "playerName": "R Kitto",
                "pt": 36.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.43%"
            },
            {
                "id": "all4",
                "team": "ADL-MID",
                "playerName": "N Konstandopoulos",
                "pt": 127.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 19.36%"
            },
            {
                "id": "all5",
                "team": "NJ-MID",
                "playerName": "S Ugarkovic",
                "pt": 449.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 15.93%"
            },
            {
                "id": "all6",
                "team": "NJ-MID",
                "playerName": "A Thurgate",
                "pt": 362.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 29.09%"
            },
            {
                "id": "all7",
                "team": "NJ-MID",
                "playerName": "R Najjarine",
                "pt": 206.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 23.56%"
            },
            {
                "id": "all8",
                "team": "ADL-MID",
                "playerName": "L DArrigo",
                "pt": 440.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.52%"
            },
            {
                "id": "all9",
                "team": "ADL-MID",
                "playerName": "J Caletti",
                "pt": 233.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.22%"
            },
            {
                "id": "all10",
                "team": "ADL-MID",
                "playerName": "D Costanzo",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.55%"
            },
            {
                "id": "all11",
                "team": "NJ-MID",
                "playerName": "J Simmons",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.55%"
            },
            {
                "id": "all12",
                "team": "NJ-MID",
                "playerName": "J Hoffman",
                "pt": 175.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.66%"
            },
            {
                "id": "all13",
                "team": "NJ-MID",
                "playerName": "K Petratos",
                "pt": 83.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.33%"
            },
            {
                "id": "all14",
                "team": "NJ-MID",
                "playerName": "L Mauragis",
                "pt": 91.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.55%"
            },
            {
                "id": "all15",
                "team": "NJ-MID",
                "playerName": "A Abbas",
                "pt": 42.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.66%"
            },
            {
                "id": "all16",
                "team": "NJ-MID",
                "playerName": "L Prso",
                "pt": 70.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.44%"
            },
            {
                "id": "all17",
                "team": "ADL-MID",
                "playerName": "J Cavallo",
                "pt": 27.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 61.95%"
            },
            {
                "id": "all18",
                "team": "NJ-MID",
                "playerName": "B Kantarovski",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 60.73%"
            },
            {
                "id": "all19",
                "team": "NJ-MID",
                "playerName": "J Armson",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 61.28%"
            },
            {
                "id": "all20",
                "team": "NJ-MID",
                "playerName": "S Abimanyu",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.55%"
            },
            {
                "id": "all21",
                "team": "NJ-MID",
                "playerName": "L Krasniqi",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.77%"
            },
            {
                "id": "all22",
                "team": "ADL-MID",
                "playerName": "J Yull",
                "pt": 3.0,
                "credit": 7.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 59.51%"
            }
        ],
        "straight": [
            {
                "id": "bowl1",
                "team": "ADL-ST",
                "playerName": "T Juric",
                "pt": 313.0,
                "credit": 10.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 87.72%"
            },
            {
                "id": "bowl2",
                "team": "ADL-ST",
                "playerName": "M Toure",
                "pt": 225.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 19.36%"
            },
            {
                "id": "bowl3",
                "team": "ADL-ST",
                "playerName": "A Toure",
                "pt": 29.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 70.24%"
            },
            {
                "id": "bowl4",
                "team": "NJ-ST",
                "playerName": "V Yuel",
                "pt": 419.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 10.29%"
            },
            {
                "id": "bowl5",
                "team": "NJ-ST",
                "playerName": "R ODonovan",
                "pt": 281.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 45.35%"
            },
            {
                "id": "bowl6",
                "team": "ADL-ST",
                "playerName": "C Goodwin",
                "pt": 186.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.54%"
            },
            {
                "id": "bowl7",
                "team": "ADL-ST",
                "playerName": "K Yengi",
                "pt": 129.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.66%"
            },
            {
                "id": "bowl8",
                "team": "ADL-ST",
                "playerName": "P Niyongabire",
                "pt": 113.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.77%"
            },
            {
                "id": "bowl9",
                "team": "ADL-ST",
                "playerName": "Y Dukuly",
                "pt": 76.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.66%"
            },
            {
                "id": "bowl10",
                "team": "NJ-ST",
                "playerName": "A Stamatelopoulos",
                "pt": 10.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1%"
            },
            {
                "id": "bowl11",
                "team": "NJ-ST",
                "playerName": "Y Petratos",
                "pt": 13.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.55%"
            },
            {
                "id": "bowl12",
                "team": "NJ-ST",
                "playerName": "T Yengi",
                "pt": 20.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.44%"
            },
            {
                "id": "bowl13",
                "team": "NJ-ST",
                "playerName": "A Goodwin",
                "pt": 12.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.77%"
            }
        ]
    },
    {
        "matchtype": "Turkish League",
        "team1Name": "KON",
        "team2Name": "ALN",
        "match": "KON vs ALN",
        "date": "21-03-2021, 03:34 PM",
        "time": "",
        "place": "",
        "stadium": "",
        "goalkeeper": [
            {
                "id": "wk1",
                "team": "KON-GK",
                "playerName": "I Sehic",
                "pt": 112.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.02%"
            },
            {
                "id": "wk2",
                "team": "KON-GK",
                "playerName": "E Birnican",
                "pt": 121.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.26%"
            },
            {
                "id": "wk3",
                "team": "ALN-GK",
                "playerName": "J Marafona",
                "pt": 175.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 80.76%"
            },
            {
                "id": "wk4",
                "team": "KON-GK",
                "playerName": "E Ersu",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.13%"
            },
            {
                "id": "wk5",
                "team": "ALN-GK",
                "playerName": "S Kirintili",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.03%"
            },
            {
                "id": "wk6",
                "team": "KON-GK",
                "playerName": "O Oruc",
                "pt": 0.0,
                "credit": 7.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.8%"
            },
            {
                "id": "wk7",
                "team": "ALN-GK",
                "playerName": "A Cagri-Guney",
                "pt": 0.0,
                "credit": 7.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.01%"
            }
        ],
        "defender": [
            {
                "id": "bat1",
                "team": "KON-DEF",
                "playerName": "G Sitya",
                "pt": 226.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 82.21%"
            },
            {
                "id": "bat2",
                "team": "KON-DEF",
                "playerName": "N Skubic",
                "pt": 303.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 90.04%"
            },
            {
                "id": "bat3",
                "team": "ALN-DEF",
                "playerName": "S Caulker",
                "pt": 156.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 78.19%"
            },
            {
                "id": "bat4",
                "team": "ALN-DEF",
                "playerName": "F Moubandje",
                "pt": 163.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 83.67%"
            },
            {
                "id": "bat5",
                "team": "KON-DEF",
                "playerName": "A Calik",
                "pt": 289.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.81%"
            },
            {
                "id": "bat6",
                "team": "KON-DEF",
                "playerName": "A Demirbag",
                "pt": 49.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.13%"
            },
            {
                "id": "bat7",
                "team": "KON-DEF",
                "playerName": "A Bardakci",
                "pt": 346.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 8.17%"
            },
            {
                "id": "bat8",
                "team": "ALN-DEF",
                "playerName": "F Aksoy",
                "pt": 63.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.13%"
            },
            {
                "id": "bat9",
                "team": "ALN-DEF",
                "playerName": "Juanfran-Junior",
                "pt": 129.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.02%"
            },
            {
                "id": "bat10",
                "team": "ALN-DEF",
                "playerName": "G Tzavellas",
                "pt": 226.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 19.8%"
            },
            {
                "id": "bat11",
                "team": "KON-DEF",
                "playerName": "M Anicic",
                "pt": 17.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.14%"
            },
            {
                "id": "bat12",
                "team": "KON-DEF",
                "playerName": "A Uludag",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.38%"
            },
            {
                "id": "bat13",
                "team": "KON-DEF",
                "playerName": "B Yardimci",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 7.27%"
            },
            {
                "id": "bat14",
                "team": "ALN-DEF",
                "playerName": "A Celebi",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.26%"
            },
            {
                "id": "bat15",
                "team": "ALN-DEF",
                "playerName": "T Bingol",
                "pt": 100.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.8%"
            },
            {
                "id": "bat16",
                "team": "ALN-DEF",
                "playerName": "A Gulay",
                "pt": 22.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.01%"
            }
        ],
        "middle": [
            {
                "id": "all1",
                "team": "ALN-MID",
                "playerName": "D Pereira",
                "pt": 87.0,
                "credit": 10.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 66.22%"
            },
            {
                "id": "all2",
                "team": "KON-MID",
                "playerName": "M Jevtovic",
                "pt": 381.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 89.04%"
            },
            {
                "id": "all3",
                "team": "KON-MID",
                "playerName": "L Shengelia",
                "pt": 226.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 6.04%"
            },
            {
                "id": "all4",
                "team": "KON-MID",
                "playerName": "A Hadziahmetovic",
                "pt": 324.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 19.69%"
            },
            {
                "id": "all5",
                "team": "ALN-MID",
                "playerName": "S Ucan",
                "pt": 148.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 74.72%"
            },
            {
                "id": "all6",
                "team": "ALN-MID",
                "playerName": "E Karaca",
                "pt": 162.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 86.35%"
            },
            {
                "id": "all7",
                "team": "KON-MID",
                "playerName": "I Diomande",
                "pt": 63.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.12%"
            },
            {
                "id": "all8",
                "team": "KON-MID",
                "playerName": "D Milosevic",
                "pt": 214.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.79%"
            },
            {
                "id": "all9",
                "team": "KON-MID",
                "playerName": "F Miya",
                "pt": 41.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.78%"
            },
            {
                "id": "all10",
                "team": "KON-MID",
                "playerName": "O Guctekin",
                "pt": 68.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.89%"
            },
            {
                "id": "all11",
                "team": "KON-MID",
                "playerName": "E Pehlivan",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.13%"
            },
            {
                "id": "all12",
                "team": "KON-MID",
                "playerName": "Z Bytyqi",
                "pt": 159.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.01%"
            },
            {
                "id": "all13",
                "team": "KON-MID",
                "playerName": "S E Eduok",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 2.01%"
            },
            {
                "id": "all14",
                "team": "KON-MID",
                "playerName": "A Rahmanovic",
                "pt": 3.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.01%"
            },
            {
                "id": "all15",
                "team": "ALN-MID",
                "playerName": "M Siopis",
                "pt": 112.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.45%"
            },
            {
                "id": "all16",
                "team": "ALN-MID",
                "playerName": "C Gulselam",
                "pt": 22.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.78%"
            },
            {
                "id": "all17",
                "team": "ALN-MID",
                "playerName": "E Bekiroglu",
                "pt": 20.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.78%"
            },
            {
                "id": "all18",
                "team": "ALN-MID",
                "playerName": "B Kutlu",
                "pt": 193.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.47%"
            },
            {
                "id": "all19",
                "team": "KON-MID",
                "playerName": "M Cagiran",
                "pt": 79.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.36%"
            },
            {
                "id": "all20",
                "team": "KON-MID",
                "playerName": "V Findikli",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.36%"
            },
            {
                "id": "all21",
                "team": "KON-MID",
                "playerName": "I Karaboga",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 3.92%"
            },
            {
                "id": "all22",
                "team": "KON-MID",
                "playerName": "I Guven",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.01%"
            },
            {
                "id": "all23",
                "team": "KON-MID",
                "playerName": "D Golpek",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 0.89%"
            },
            {
                "id": "all24",
                "team": "ALN-MID",
                "playerName": "H H Acar",
                "pt": 62.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.57%"
            },
            {
                "id": "all25",
                "team": "ALN-MID",
                "playerName": "Y Ozdemir",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.12%"
            },
            {
                "id": "all26",
                "team": "ALN-MID",
                "playerName": "E M Tetah",
                "pt": 0.0,
                "credit": 8.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.01%"
            },
            {
                "id": "all27",
                "team": "KON-MID",
                "playerName": "H Biber",
                "pt": 0.0,
                "credit": 7.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 9.17%"
            }
        ],
        "straight": [
            {
                "id": "bowl1",
                "team": "KON-ST",
                "playerName": "A Kravets",
                "pt": 157.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.59%"
            },
            {
                "id": "bowl2",
                "team": "KON-ST",
                "playerName": "S Cikalleshi",
                "pt": 242.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 74.38%"
            },
            {
                "id": "bowl3",
                "team": "ALN-ST",
                "playerName": "K Babacar",
                "pt": 202.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 35.57%"
            },
            {
                "id": "bowl4",
                "team": "ALN-ST",
                "playerName": "A Bareiro",
                "pt": 123.0,
                "credit": 9.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 14.88%"
            },
            {
                "id": "bowl5",
                "team": "KON-ST",
                "playerName": "J Sekidika",
                "pt": 218.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.92%"
            },
            {
                "id": "bowl6",
                "team": "KON-ST",
                "playerName": "E Daci",
                "pt": 148.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 1.45%"
            },
            {
                "id": "bowl7",
                "team": "ALN-ST",
                "playerName": "M Pektemek",
                "pt": 89.0,
                "credit": 9.0,
                "isPlayLastMatch": "",
                "selby": "Sel by 4.92%"
            },
            {
                "id": "bowl8",
                "team": "KON-ST",
                "playerName": "A Karademir",
                "pt": 0.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 11.19%"
            },
            {
                "id": "bowl9",
                "team": "ALN-ST",
                "playerName": "U Gunes",
                "pt": 32.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 50.67%"
            },
            {
                "id": "bowl10",
                "team": "ALN-ST",
                "playerName": "D Kadzior",
                "pt": 66.0,
                "credit": 8.5,
                "isPlayLastMatch": "",
                "selby": "Sel by 5.71%"
            }
        ]
    }
];