let authenticate = function()
{
    let main_flag = localStorage.getItem('cricket')
    let sub_flag_one = localStorage.getItem('num1')
    let sub_flag_two = localStorage.getItem('num2')
    if(main_flag=='present' && sub_flag_one=='13' && sub_flag_two=='91')
    {
        let temp = parseInt((new Date()).getDate())
        let temp_sub = parseInt(localStorage.getItem('date'))
       // console.log(temp)
       // console.log(temp_sub)
        if(temp!=temp_sub)
        {
           // console.log('here')
            store_teams()
            localStorage.setItem('date',temp)
        }
    }
    else
    {
        localStorage.setItem('cricket','present')
        localStorage.setItem('num1','13')
        localStorage.setItem('num2','91')
        localStorage.setItem('date',(new Date()).getDate())
    }
}
