[
    {
        "team_name":"MS",
        "players_name":["Katherine Brunt", "Lucy Cripps", "Sophie Day", "Bhavi Devchand", "Nicole Faltum", "Holly Ferling", "Tess Flintoff", "Georgia Gall", "Alana King", "Meg Lanning", "Erin Osborne", "Mignon du Preez", "Nat Sciver", "Annabel Sutherland", "Elyse Villani", ],
        "players_role":[4, 2, 2, 3, 1, 4, 4, 4, 4, 2, 3, 2, 3, 3, 2, ],
        "players_credits":[9, 8, 7.5, 8, 8, 8.5, 8, 7.5, 8, 10, 9, 9.5, 10, 8.5, 9, ],
        "players_image":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15],
    }
    ,
    {
        "team_name":"AS",
        "players_name":[" Darcie Brown", "Suzie 2es", "Sarah Coyte", "Ellie Falconer", "Amanda-Jade Wellington", "Katie Mack", "Tegan McPharlin", "Tahlia McGrath", "Annie ONeil", "Bridget Patterson", "Madeline Penna", "Alex Price", "Megan Schutt", "Stafanie Taylor", "Laura Wolvaardt", ],
        "players_role":[4, 3, 4, 4, 4, 2, 1, 3, 2, 2, 4, 4, 4, 3, 2, ],
        "players_credits":[8, 9.5, 9, 8, 8.5, 8.5, 8.5, 9, 8, 9, 8.5, 8, 9.5, 9.5, 8.5, ],
        "players_image":[16,17,18,19,20,21,22,23,24,25,26,27,28,29,30],
    },
    {
      "team_name":"BH",
      "players_name":["Maddy Green", "Nicola Hancock", "Grace Harris", "Laura Harris", "Mikayla Hinkley", "Jess Jonassen", "Amelia Kerr", "Delissa Kimmince", "Nadine de Klerk", "Charli Knott", "Lilly Mills", "Georgia Prestwidge", "Georgia Redmayne", "Courtney Sippel", "Georgia Voll", ],
      "players_role":[2, 4, 3, 2, 2, 3, 3, 4, 3, 2, 3, 4, 1, 4, 2, ],
      "players_credits":[9, 8, 9.5, 8.5, 8, 10, 9.5, 9, 8.5, 8, 8, 8.5, 8.5, 8, 8.5, ],
      "players_image":[31,32,33,34,35,36,37,38,39,40,41,42,43,44,45],
    },
    {
      "team_name":"HH",
      "players_name":["Nicola Carey", "Corinne Hall", "Brooke Hepburn", "Erica Kershaw", "Hayley Matthews", "Sasha Moloney", "Rachel Priest", "Chloe Rafferty", "Amy Smith", "Naomi Stalenberg", "Emma Thompson", "Chloe Tryon", "H Jensen", "Belinda Vakarewa", ],
      "players_role":[3, 2, 4, 1, 3, 2, 1, 4, 4, 2, 2, 3, 4, 4, ],
      "players_credits":[9.5, 9, 8, 8, 9, 8, 8.5, 8.5, 8, 9, 8, 9, 9, 9, ],
      "players_image":[46,47,48,49,50,51,52,53,54,55,56,57,58,59],
    },
    {
      "team_name":"MR",
      "players_name":["Makinley Blows", "Maitlan Brown", "Josie Dooley", "Erin Fazackerley", "Ella Hayward", "Lizelle Lee", "Carly Leeson", "Sophie Molineux", "Courtney Neale", "Amy Satterthwaite", "Molly Strano", "Lea Tahuhu", "Georgia Wareham", "Courtney Webb", ],
      "players_role":[3, 4, 1, 2, 3, 1, 4, 3, 4, 2, 4, 4, 4, 2, ],
      "players_credits":[8, 8.5, 9.5, 9, 8, 8.5, 8, 9, 8, 9.5, 9.5, 8.5, 8.5, 8.5, ],
      "players_image":[60,61,62,63,64,65,66,67,68,69,70,71,72,73],
    },
    {
      "team_name":"PS",
      "players_name":["Megan Banting", "Jemma Barsby", "Samantha Betts", "Nicole Bolton", "Mathilda Carmichael", "Piepa Cleary", "Sophie Devine", "Sarah Glenn", "Heather Graham", "Amy Jones", "Beth Mooney", "Taneale Peschel", "Chloe Piparo", "Georgia Wyllie", "Emma King", ],
      "players_role":[1, 4, 4, 3, 2, 4, 3, 4, 3, 1, 2, 4, 2, 2, 4, ],
      "players_credits":[8, 8, 8.5, 8.5, 8, 8, 11, 9, 8.5, 9.5, 10.5, 8.5, 8, 8, 8, ],
      "players_image":[74,75,76,77,78,79,80,81,82,83,84,85,86,87,88],
    },
    {
      "team_name":"SS",
      "players_name":["Sarah Aley", "Erin Burns", "Stella Campbell", "Lauren Cheatle", "Maddy Darke", "Ashleigh Gardner", "Lisa Griffith", "Alyssa Healy", "Jodie Hicks", "Emma Hughes", "Marizanne Kapp", "Ellyse Perry", "Angela Reakes", "Hayley Silver-Holmes", "Dane van Niekerk", ],
      "players_role":[4, 2, 4, 4, 1, 2, 4, 1, 2, 4, 3, 3, 2, 4, 3, ],
      "players_credits":[8.5, 8.5, 8, 8, 8, 9, 8, 10, 8, 8, 9.5, 10.5, 8, 8.5, 9.5, ],
      "players_image":[89,90,91,92,93,94,95,96,97,98,99,100,101,02,103],
    },
    {
      "team_name":"ST",
      "players_name":["Sam 2es", "Tammy Beaumont", "Hannah Darlington", "Rachael Haynes", "Saskia Horley", "Shabnim Ismail", "Anika Learoyd", "Phoebe Litchfield", "Heather Knight", "Kate Peterson", "Lauren Smith", "Rachel Trenaman", "Tahlia Wilson", "Sammy-Jo Johnson", ],
      "players_role":[4, 1, 4, 2, 3, 4, 2, 2, 2, 4, 4, 3, 1, 3, ],
      "players_credits":[8.5, 9, 8.5, 9.5, 8, 9.5, 8, 8.5, 10, 8, 8, 8, 8.5, 8.5, ],
      "players_image":[104,105,106,107,108,109,110,111,112,113,114,115,116,117],
    },
]